// this surveyform.js file's function do show the number of size in survey form so that user can see the change of value they selected.
// write in the html using innerHTML function.

function sizeForSpecific(iSize)
{
    document.getElementById("specificPurpose").innerHTML = iSize
}

function sizeForDistracted(iSize)
{
    document.getElementById("distracted").innerHTML = iSize
}

function sizeForRestless(iSize)
{
    document.getElementById("restless").innerHTML = iSize
}

function sizeForEasyDistracted(iSize)
{
    document.getElementById("easyDistracted").innerHTML = iSize
}

function sizeForBothered(iSize)
{
    document.getElementById("bothered").innerHTML = iSize
}

function sizeForDifficultConcent(iSize)
{
    document.getElementById("difficultConcent").innerHTML = iSize
}

function sizeForCompare(iSize)
{
    document.getElementById("compare").innerHTML = iSize
}

function sizeForfeelComperisons(iSize)
{
    document.getElementById("feelComperisons").innerHTML = iSize
}

function sizeForValidation(iSize)
{
    document.getElementById("validation").innerHTML = iSize
}

function sizeForDepressed(iSize)
{
    document.getElementById("depressed").innerHTML = iSize
}

function sizeForDailyActivities(iSize)
{
    document.getElementById("dailyActivities").innerHTML = iSize
}

function sizeForSleep(iSize)
{
    document.getElementById("sleep").innerHTML = iSize
}


  