# Intex2023
This is for our groups intex project

# TA Section: How to use out website

Go to provomentalhealth.3-2.is404.net

You can login as an admin by pressing "login" then entering "admin" as both the username and password.
You can then go to the 'Employees' page to see a list of all users and their logins. There you can create a new user to test normal employee login and functionality.

Once logged in as a different employee, the 'Edit Proflie' page will let you change your login info. You can also view the list of surveys as an employee or admin. In this list, you can search for a specific survey entry by using the search bar or other filters. You can edit or delete a specific entry by pushing the respective button.

To create a survey, logout and there will be a button on your initial landing page. It will take you to the survey form.

# Git Commands
!!!! IMPORTANT!!!!
DO NOT PUSH STRAIGHT TO MAIN, IT WILL DEPLOY AUTOMATICALLY
Create a new branch: 
git checkout -b "branch_name"

Switch Branches:
git checkout branch_name

Push your code:
git add .
git commit -m "commit message"
git push

Pull code:
git pull
If that doesn't work, do git fetch, then git pull

Color Scheme:
Blue: #3689ff use for accent color (buttons and stuff)
Off-White: #fbfcff use for backgrounds
Gray: #263043 use for text
Other Blue: #086fff Hover color for buttons

Font
font-family: Arial, sans-serif;
